﻿<?php 
$name =$_POST['n'];
$name =$_POST['n'];
$url = 'http://' . $_SERVER['HTTP_HOST'];
?>
<html>
<head>
<!---This Script Edited and Designed Kishan Raj ----->



<meta http-equiv="Content-Type" content="text/html; utf-8">
    <meta name="google" content="notranslate">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0" name="viewport">
    <meta property="og:type" content="!! छठ पूजा की शुभकामनायें !!">
    <meta property="og:title" content="!! छठ पूजा की शुभकामनायें !!">
    
    <meta property="og:description" content="!! छठ पूजा की शुभकामनायें !!">
    <meta property="og:site_name" content="!! छठ पूजा की शुभकामनायें !!">
    <meta property="og:image" content="Pics\k111.png"> 
    <title> !! छठ पूजा की शुभकामनायें !!</title>
    <link rel="stylesheet" href="animate.min.css">

    <script type="text/javascript">! function (){var t;try{for (t=0; 10 > t; ++t) history.pushState({}, "", "#");onpopstate=function (t){t.state &&   alert("अपना wishing अपने मित्रो और अपने परिजनों के साथ शेयर करे !!");}}catch (o){}}();</script>
<!-- Analytics -->

<!-- Global site tag (gtag.js) - Google Analytics -->


<!-- Analytics -->
<style>
body{
        background: #f8f8f8;
        margin:0;
      }
      .mainContainer {
        background: white;
        max-width: 450px;
        min-height: 200px;
        margin: 0 auto;
        text-align: center;
        padding: 15px;
        color: #999;
        padding-bottom: 60px;

        box-shadow: 0 0 10px 1px rgba(0,0,0,.14), 0 1px 14px 2px rgba(0,0,0,.12), 0 0 5px -3px rgba(0,0,0,.3);


      }

#name {
     
      animation: name 4s infinite; 
      text-transform: capitalize;
      margin-bottom: 5px;
      font-size: 50px;
      padding: 0 10px;
      font-family: 'Teko', sans-serif;
} 

#usernameb { color: black;  /* Fallback: assume this color ON TOP of image */
   background: url(Pics/sname.gif);
   -webkit-background-clip: text;
   -webkit-text-fill-color: transparent;
          animation: swing 4s infinite;
            text-transform: uppercase;
          margin-bottom: 5px;
          font-size: 25px;
          padding: 0 10px;
    font-family: 'SF Espresso Shack', cursive;
}


.m1{position:fixed;left:1%; width:auto;height:100%;top:1%;color:#000;}
.m2{position:fixed;right:1%; width:auto;height:100%;top:1%;color:#000;}


/* Custom Animation classes */     
.name {
	color: #fff;
    	margin: 6px;
    	padding: 25px 20px;
    	font-size: 48px;
    	font-family: sans-serif;
}

.enter-name input[type=name] {
	background-color: yellow;
	color: black;
	font-weight:bold;
   	border-radius: 10px;
    	box-sizing: border-box;
    	border:2px solid black;
    	padding: 5px;
    	position: fixed;
    	left: 10px;
    	bottom: 5px;
    	height: 50px;
    	width: 70%;
    	text-align: center;
    	font-size: 22px;
    	display: inline-block;
}

.enter-name .btn {
	border-radius: 10px;
    	font-size: 21px;
    	padding: 4px;
    	position: fixed;
    	right: 2px;
    	bottom: 5px;
    	height: 50px;
    	width: 23%;
    	display: inline-block;
    	color: white;
    	font-weight:600;
    	background-color: red;
    	border: 2px solid black;
    	letter-spacing: .5px;
    	transition: .2s ease-out;
    	cursor: pointer;
    	line-height: 36px;
    	outline: 0;
    	text-transform: uppercase;
    	vertical-align: middle;
    	text-decoration: none;
    	animation-duration: 4s !important;
}

.enter-name input[type=name]::-webkit-input-placeholder { 
	color: black;
  	font-size: 18px;	
}

.enter-name input[type=name]::-moz-placeholder { 
	color: black;
  	font-size: 18px;
}

.enter-name input[type=name]:focus::-webkit-input-placeholder {
    color: black;
}

.enter-name input[type=name]:focus::-moz-placeholder { 
	color: black;
  	font-size: 18px;
}


#demo
{
    text-shadow: 1px 1px 3px #ff0037, 1px 1px 3px #ff0037, -1px -1px 3px #ff0037, -1px -1px 3px #ff0037;
    color: #efff00;
    font-size: 20px;
    font-weight: bold;
    animation: pulse 2s infinite;
    width:87%;
    margin:auto;
}




a.rope
{
    text-decoration:none;
}
.wishMessage {
        color: #fff;
        font-size: 22px;
        font-weight: bold;
        margin-top: 20px;
        text-shadow: 0px 0px 10px #afafaf;
      }
      .wishMessage p{
        margin: 0.3em 0;
      }
/* Custom Animation classes */ 
#show-name {
  font-size: 25px;
  display: inline-block;
  margin-bottom: 5px;
  animation: swing 1s infinite, glow 20s infinite; }

@keyframes glow {
  0%, 100% {
    text-shadow: 0 0 30px red; }
  25% {
    text-shadow: 0 0 30px orange; }
  50% {
    text-shadow: 0 0 30px forestgreen; }
  75% {
    text-shadow: 0 0 30px cyan; } }  
figure {
  animation:wobble 5s ease-in-out infinite;
  transform-origin:center center;
  transform-style:preserve-3d;
}@keyframes wobble {
  0%,100%{ transform:rotate3d(1,1,0,40deg); }
  25%{ transform:rotate3d(-1,1,0,40deg); }
  50%{ transform:rotate3d(-1,-1,0,40deg); }
  75%{ transform:rotate3d(1,-1,0,40deg); }
}
</style>

<style type="text/css">
      *{
        margin:0;
        padding:0;
      }
      body {
        text-align: center;
        
      }
      img{
      border: none;
    }
.leftcurtain{
      width: 100%;
      height: 120%;
      top: 0px;
      left: 0px;
      position: absolute;
      z-index: 2;
    }
     .rightcurtain{
      width: 100%;
      height: 120%;
      right: 0px;
      top: 0px;
      position: absolute;
      z-index: 3;
    }
    .rightcurtain img, .leftcurtain img{
      width: 100%;
      height: 100%;
    }
    .logo{
      margin: 0px auto;
      margin-top: 150px;
    }
    .rope{
      position: absolute;
      top: 160px;
      left: 28%;
      z-index: 4;
    } 
.centered {
    position: absolute;
    top: 70%;
    left: 55%;
    transform: translate(-50%, -50%);
}
a.rope
{
    text-decoration:none;
}


  .matki{
  animation: aadisoni linear 5s;
  animation-iteration-count: infinite;
  transform-origin: 50% 100%;
  animation-fill-mode:forwards; /*when the spec is finished*/
  -webkit-animation: aadisoni linear 5s;
  -webkit-animation-iteration-count: infinite;
  -webkit-transform-origin: 50% 100%;
  -webkit-animation-fill-mode:forwards; /*Chrome 16+, Safari 4+*/ 
}

@keyframes aadisoni{
  0% {
    transform:  translate(0px,0px)  rotate(0deg) ;
  }
  15% {
    transform:  translate(-25px,0px)  rotate(-5deg) ;
  }
  30% {
    transform:  translate(20px,0px)  rotate(3deg) ;
  }
  45% {
    transform:  translate(-15px,0px)  rotate(-3deg) ;
  }
  60% {
    transform:  translate(10px,0px)  rotate(2deg) ;
  }
  75% {
    transform:  translate(-5px,0px)  rotate(-1deg) ;
  }
  100% {
    transform:  translate(0px,0px)  rotate(0deg) ;
  }
}

@-webkit-keyframes aadisoni {
  0% {
    -webkit-transform:  translate(0px,0px)  rotate(0deg) ;
  }
  15% {
    -webkit-transform:  translate(-25px,0px)  rotate(-5deg) ;
  }
  30% {
    -webkit-transform:  translate(20px,0px)  rotate(3deg) ;
  }
  45% {
    -webkit-transform:  translate(-15px,0px)  rotate(-3deg) ;
  }
  60% {
    -webkit-transform:  translate(10px,0px)  rotate(2deg) ;
  }
  75% {
    -webkit-transform:  translate(-5px,0px)  rotate(-1deg) ;
  }
  100% {
    -webkit-transform:  translate(0px,0px)  rotate(0deg) ;
  }
}



@keyframes name {
  0%   {color:red;}
  20%   {color:white;}
  40%   {color:yellow;}
  60%   {color:orange;}
  80%   {color:cyan;}
  100% {color:#f45bf4;}
}


.glow {
  width:50%;
  padding: 2px;
  background-color: #FF1493	;
  animation: glow 2s infinite;
  font-size:25px;
  font-family: 'Ranga', cursive;
  color:white;
  margin:auto;
  text-align:center;
  border-radius:10px;
  text-shadow:1px 2px 6px black;

}

@keyframes glow {
  0%   {box-shadow: 0px 0px 0px #FF1493	;}
  100%   {box-shadow: 0px 0px 20px 5px #ffb3db;}
 
}

</style>
<style type="text/css">
*{margin:0;padding:0}body{text-align:center}img{border:none}.leftcurtain{width:100%;height:120%;top:0;left:5px;position:absolute;z-index:2}.rightcurtain{width:100%;height:120%;right:3px;top:0;position:absolute;z-index:3}.rightcurtain img,.leftcurtain img{width:100%;height:100%}.logo{margin:0 auto;margin-top:150px}.rope{position:absolute;top:0;left:20%;z-index:4}.centered{position:absolute;top:75%;left:50%;transform:translate(-50%,-50%)}.aadi{background-image:url();background-repeat:no-repeat;background-attachment:fixed;background-position:top}.matki{animation:aadisoni linear 5s;animation-iteration-count:infinite;transform-origin:50% 100%;animation-fill-mode:forwards;-webkit-animation:aadisoni linear 5s;-webkit-animation-iteration-count:infinite;-webkit-transform-origin:50% 100%;-webkit-animation-fill-mode:forwards}@keyframes aadisoni{0%{transform:translate(0px,0px) rotate(0deg)}15%{transform:translate(-25px,0px) rotate(-5deg)}30%{transform:translate(20px,0px) rotate(3deg)}45%{transform:translate(-15px,0px) rotate(-3deg)}60%{transform:translate(10px,0px) rotate(2deg)}75%{transform:translate(-5px,0px) rotate(-1deg)}100%{transform:translate(0px,0px) rotate(0deg)}}@-webkit-keyframes aadisoni{0%{-webkit-transform:translate(0px,0px) rotate(0deg)}15%{-webkit-transform:translate(-25px,0px) rotate(-5deg)}30%{-webkit-transform:translate(20px,0px) rotate(3deg)}45%{-webkit-transform:translate(-15px,0px) rotate(-3deg)}60%{-webkit-transform:translate(10px,0px) rotate(2deg)}75%{-webkit-transform:translate(-5px,0px) rotate(-1deg)}100%{-webkit-transform:translate(0px,0px) rotate(0deg)}}
#username {
     color: black;  /* Fallback: assume this color ON TOP of image */
   background: url(img/namegif.gif);
   -webkit-background-clip: text;
   -webkit-text-fill-color: transparent;
          animation: swing 4s infinite;
            text-transform: uppercase;
          margin-bottom: 5px;
          font-size: 40px;
          padding: 0 10px;
    font-family: 'SF Espresso Shack', cursive;
} 

#usernameb { color: black;  /* Fallback: assume this color ON TOP of image */
   background: url(img/namegif.gif);
   -webkit-background-clip: text;
   -webkit-text-fill-color: transparent;
          animation: swing 4s infinite;
            text-transform: uppercase;
          margin-bottom: 5px;
          font-size: 25px;
          padding: 0 10px;
    font-family: 'SF Espresso Shack', cursive;
}
.footerbtn {
 
            display: block;
            line-height: 20px;
            position: fixed;
            left:0px;
            bottom:10px;
            height:60px;
            
border-radius: 15px;
  box-sizing: border-box;
  padding: 5px;
  background:#34af23;
  color: #ffffff;
  font-size:22px;
  text-align: center;
  text-decoration: none;
  width:95%;
 margin-left:10px;
            margin-right:30px;
            box-shadow: 0 4px 12px 0 rgba(0, 0, 0, .3);
            animation: footer infinite linear 1s;
            -webkit-transform: translate3d(30%,0,0);
            transform: translate3d(30%,0,0);
            position: fixed;
           
}

.footerbtn :active {
            box-shadow: none
        }

        @-webkit-keyframes footer {
            from {
                -webkit-transform: rotateZ(0)
            }
            25% {
                -webkit-transform: rotateZ(1.5deg)
            }
            50% {
                -webkit-transform: rotateZ(0deg)
            }
            75% {
                -webkit-transform: rotateZ(-1.5deg)
            }
            to {
                -webkit-transform: rotateZ(0)
            }}
  </style>
</head>
<script src="https://code.createjs.com/createjs-2015.11.26.min.js"></script>
<audio controls="" autoplay="" loop="" style="display:none">
		<source src="KsN/kishan2.mp3" type="audio/mpeg">
		
	</audio>
<marquee class="m1" behavior="scroll" direction="up" scrolldelay="0"> <br>
<img src="Pics\1.png" height="40px" width="30px"><br><br>
<img src="Pics\2.png" height="40px" width="30px"><br><br>
<img src="Pics\3.png" height="40px" width="30px"><br><br>
<img src="Pics\1.png" height="40px" width="30px"><br><br>
<img src="Pics\2.png" height="40px" width="30px"><br><br>
<img src="Pics\3.png" height="40px" width="30px"><br><br>
<img src="Pics\1.png" height="40px" width="30px"><br><br>
<img src="Pics\2.png" height="40px" width="30px"><br><br>
<img src="Pics\3.png" height="40px" width="30px"><br><br>
<img src="Pics\1.png" height="40px" width="30px"><br><br>
<img src="Pics\2.png" height="40px" width="30px"><br><br>
<img src="Pics\3.png" height="40px" width="30px"><br><br>
<img src="Pics\1.png" height="40px" width="30px"><br><br>
<img src="Pics\2.png" height="40px" width="30px"><br><br>
<img src="Pics\3.png" height="40px" width="30px"><br><br>
<img src="Pics\1.png" height="40px" width="30px"><br><br>
<img src="Pics\2.png" height="40px" width="30px"><br><br>
<img src="Pics\3.png" height="40px" width="30px"><br><br>
<img src="Pics\1.png" height="40px" width="30px"><br><br>
<img src="Pics\2.png" height="40px" width="30px"><br><br>
<img src="Pics\3.png" height="40px" width="30px"><br><br>
<img src="Pics\1.png" height="40px" width="30px"><br><br>
<img src="Pics\2.png" height="40px" width="30px"><br><br>
<img src="Pics\3.png" height="40px" width="30px"><br><br>
<img src="Pics\1.png" height="40px" width="30px"><br><br>
<img src="Pics\2.png" height="40px" width="30px"><br><br>
<img src="Pics\3.png" height="40px" width="30px"><br><br>
<img src="Pics\1.png" height="40px" width="30px"><br><br>
<img src="Pics\2.png" height="40px" width="30px"><br><br>
<img src="Pics\3.png" height="40px" width="30px"><br><br>
<img src="Pics\1.png" height="40px" width="30px"><br><br>
<img src="Pics\2.png" height="40px" width="30px"><br><br>
<img src="Pics\3.png" height="40px" width="30px"><br><br>
<img src="Pics\1.png" height="40px" width="30px"><br><br>
<img src="Pics\2.png" height="40px" width="30px"><br><br>
<img src="Pics\3.png" height="40px" width="30px"><br><br>
</marquee>
<marquee class="m2" behavior="scroll" direction="down" scrolldelay="0"> <br>
<img src="Pics\1.png" height="40px" width="30px"><br><br>
<img src="Pics\2.png" height="40px" width="30px"><br><br>
<img src="Pics\3.png" height="40px" width="30px"><br><br>
<img src="Pics\1.png" height="40px" width="30px"><br><br>
<img src="Pics\2.png" height="40px" width="30px"><br><br>
<img src="Pics\3.png" height="40px" width="30px"><br><br>
<img src="Pics\1.png" height="40px" width="30px"><br><br>
<img src="Pics\2.png" height="40px" width="30px"><br><br>
<img src="Pics\3.png" height="40px" width="30px"><br><br>
<img src="Pics\1.png" height="40px" width="30px"><br><br>
<img src="Pics\2.png" height="40px" width="30px"><br><br>
<img src="Pics\3.png" height="40px" width="30px"><br><br>
<img src="Pics\1.png" height="40px" width="30px"><br><br>
<img src="Pics\2.png" height="40px" width="30px"><br><br>
<img src="Pics\3.png" height="40px" width="30px"><br><br>
<img src="Pics\1.png" height="40px" width="30px"><br><br>
<img src="Pics\2.png" height="40px" width="30px"><br><br>
<img src="Pics\3.png" height="40px" width="30px"><br><br>
<img src="Pics\1.png" height="40px" width="30px"><br><br>
<img src="Pics\2.png" height="40px" width="30px"><br><br>
<img src="Pics\3.png" height="40px" width="30px"><br><br>
<img src="Pics\1.png" height="40px" width="30px"><br><br>
<img src="Pics\2.png" height="40px" width="30px"><br><br>
<img src="Pics\3.png" height="40px" width="30px"><br><br>
<img src="Pics\1.png" height="40px" width="30px"><br><br>
<img src="Pics\2.png" height="40px" width="30px"><br><br>
<img src="Pics\3.png" height="40px" width="30px"><br><br>
<img src="Pics\1.png" height="40px" width="30px"><br><br>
<img src="Pics\2.png" height="40px" width="30px"><br><br>
<img src="Pics\3.png" height="40px" width="30px"><br><br>
<img src="Pics\1.png" height="40px" width="30px"><br><br>
<img src="Pics\2.png" height="40px" width="30px"><br><br>
<img src="Pics\3.png" height="40px" width="30px"><br><br>
<img src="Pics\1.png" height="40px" width="30px"><br><br>
<img src="Pics\2.png" height="40px" width="30px"><br><br>
<img src="Pics\3.png" height="40px" width="30px"><br><br>

</marquee>

<div class="mainContainer">

<center>
<!-- adcode -->

<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- Header Ads -->
<ins class="adsbygoogle"
     style="display:inline-block;width:600px;height:50px"
     data-ad-client="ca-pub-4875950698782625"
     data-ad-slot="2883044018"></ins>
<script>
     (adsbygoogle = window.adsbygoogle || []).push({});
</script>
<!-- adcode -->
</center>
<br>
<div style="animation: swing 4s infinite;">
<h1 style="background: url(Pics/namegif.gif);-webkit-text-fill-color: transparent;-webkit-background-clip: text;" id="name"><?php echo $name; ?></h1>
</div>
        <h3 class="fromMessage" id="fromMessage"></h3>
 <img src="Pics\ki-taraf-sey-mi.png" width="60%" height="10%" style="animation: rubberBand 2.5s infinite"><br><br>
<div style="font-size: 10px; font-weight: 550; color: black;">
      <p id="demo"></p><br>

<br>

<img src="Pics\diwali-shubh-new1.png" width="80%" height="auto" style="animation: pulse 2s infinite"><br>
<center><div class="w3-content w3-section" style="max-width:500px">
<img class="mySlides" src="Pics\k111.png" style="width:290px; height:300px;">
<img class="mySlides" src="Pics\d2.png" style="width:90%; height:250px;">
</div></center>
<center>
<!-- adcode -->

<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- Header Ads -->
<ins class="adsbygoogle"
     style="display:inline-block;width:300px;height:50px"
     data-ad-client="ca-pub-4875950698782625"
     data-ad-slot="2883044018"></ins>
<script>
     (adsbygoogle = window.adsbygoogle || []).push({});
</script>
<!-- adcode -->
</center>
<center></center>
<div class="wishMessage" style="text-shadow: 1px 1px 3px silver, 1px 1px 3px silver, -1px -1px 3px silver, -1px -1px 3px silver;">
<p style="text-shadow: 1px 1px 3px black, 1px 1px 3px black, -1px -1px 3px black, -1px -1px 3px black;color:#ff9933">गेहूं का ठेकुआ, चावल के लड्डू</p>
<p style="text-shadow: 1px 1px 3px black, 1px 1px 3px black, -1px -1px 3px black, -1px -1px 3px black;color:pink">खीर,अन्नानास, निम्बू, और कद्दू</p>
<p style="text-shadow: 1px 1px 3px black, 1px 1px 3px black, -1px -1px 3px black, -1px -1px 3px black;color:#00ffbf;width:90%;margin:auto;">छठी मैया करे हर मुराद पूरी</p>
<p style="text-shadow: 1px 1px 3px orange, 1px 1px 3px orange, -1px -1px 3px orange, -1px -1px 3px orange;color:#8B008B">बाटे घर घर लड्डू…<br>
जय छठी मैया शुभ छठ पूजा
</p>
<p style="text-shadow: 1px 1px 3px #ff0037, 1px 1px 3px #ff0037, -1px -1px 3px #ff0037, -1px -1px 3px #ff0037;color: #FFC107;">
!!आप सभी को छठ पूजा की <br>हार्दिक शुभकामनाएँ !! </p>	</div>
<span style="font-size:22px;text-shadow: 1px 1px 3px #FFEB3B, 1px 1px 3px #FFEB3B, -1px -1px 3px #FFEB3B, -1px -1px 3px #FFEB3B;color:#E91E63;"><marquee><b><i>“   की तरफ से छठ पूजा कीं हार्दिक शुभकामनाएँ!!”</b></i></marquee></span><br>


</div><br>


<br>

<div class="glow"><?php echo $name; ?></div>
<br><br>

<a class="footerbtn" href="whatsapp://send?text=*<?php echo $name; ?>* ने आपके लिए कुछ भेजा है  %0A ब्लू लाइन को टच करके देखो    👇 👇 https://alltrickzone.com/chhathpuja/?n=<?php echo $name; ?>"><img width="25px" height="25px" src="img\whatsapp.png"><b style="font-size: 19px;">👉 सबको भेजें  👈</b>  <img width="25px" height="25px" src="img\whatsapp.png">
</a>



<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script>
var myIndex=0;function carousel(){var e,l=document.getElementsByClassName("mySlides");for(e=0;e<l.length;e++)l[e].style.display="none";++myIndex>l.length&&(myIndex=1),l[myIndex-1].style.display="block",setTimeout(carousel,2e3)}carousel();
</script>

<script> 
var countDownDate=new Date("Nov 10, 2021 00:00:00").getTime(),x=setInterval(function(){var e=(new Date).getTime(),o=countDownDate-e,t=Math.floor(o/864e5),n=Math.floor(o%864e5/36e5),a=Math.floor(o%36e5/6e4),l=Math.floor(o%6e4/1e3);document.getElementById("demo").innerHTML=t+"<font color='black'> दिन,</font> "+n+"<font color='black'> घंटे,</font> "+a+"<font color='black'>  मिनट,<br></font> "+l+"<font color='black'> सेकेंड </font>पहले   ",o<0&&(clearInterval(x),document.getElementById("demo").innerHTML="")},1e3);
</script>
<script src="https://www.gstatic.com/firebasejs/7.14.6/firebase-app.js"></script>
<script src="https://www.gstatic.com/firebasejs/7.14.6/firebase-messaging.js"></script>
<script src="integrate.js?v=63"></script>



</div></html>
